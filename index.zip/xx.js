const add = (a, b) => {
  return a + b;
};

export default add;
